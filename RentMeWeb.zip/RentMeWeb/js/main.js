//menu
var tombolMenu =  $(".tombol-menu");
var menu = $("nav .menu ul");

function klikMenu(){
    tombolMenu.click(function(){
        menu.toggle();
    });
    menu.click(function(){
        menu.toggle();
    });
}//

//frame box jquery agar tanda = dapat di klik
$ (document).ready(function () {
  var width = $(window).width();
  if (width < 990) {
      klikMenu();
  }
})

//pengecekan lebar agar nav bar menyesuaikans
$(window).resize(function(){
  var width = $(window).width();
  if(width > 989){
      menu.css("display","block");
      //display:block
  }else{
      menu.css("display","none");
  }
  klikMenu();
})


//efek scroll
$ (document).ready(function () {
    var scroll_pos = 0;
    $(document).scroll(function (){
        scroll_pos = $(this).scrollTop();
        if(scroll_pos > 0){
            $("nav").addClass("putih");
            $("nav img.hitam").show();
            $("nav img.putih").hide();
        }else{
            $("nav").removeClass("putih");
            $("nav img.hitam").hide();
            $("nav img.putih").show();
        }

    }) 

    
});


//Filter Riwayat
let nodeList = document.querySelector(".buttons");

$('.buttons').click(function(){

  $(this).addClass('button-active').siblings().removeClass('button-active');

  let filter = $(this).attr('data-filter');
  if(filter == 'all'){
      $('.menu .histori').show(400);
  }else{
      $('.menu .histori').not('.'+filter).hide(200);
      $('.menu .histori').filter('.'+filter).show(400);
  }

});


